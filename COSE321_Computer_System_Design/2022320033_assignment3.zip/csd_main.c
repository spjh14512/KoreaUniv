#include <stdio.h>

#define csd_SWC_ADDR 0x41210000

int csd_main()
{
	int* ptr = csd_SWC_ADDR;						// load switch input base address
	int switches = *ptr;							// get data from gpio
	int duration = 8500000;							// 100ms = 8500000
	if (switches & (1 << 7)) {duration *= 1;}		// check whether SW7 is on
	else if (switches & (1 << 6)) {duration *= 2;}	// check whether SW6 is on
	else if (switches & (1 << 5)) {duration *= 3;}	// check whether SW5 is on
	else if (switches & (1 << 4)) {duration *= 4;}	// check whether SW4 is on
	else if (switches & (1 << 3)) {duration *= 5;}	// check whether SW3 is on
	else if (switches & (1 << 2)) {duration *= 6;}	// check whether SW2 is on
	else if (switches & (1 << 1)) {duration *= 7;}	// check whether SW1 is on
	else if (switches & 1) {duration *= 8;}			// check whether SW0 is on
	else {duration *= 10;}							// case all switches are off

	for (int i = 0; i < duration; i++) {}			// delay for duration
	return 0;										// return to csd_asm.S
}
